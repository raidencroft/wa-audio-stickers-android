// Puente mínimo para la app (reemplaza a bridge.js de la extensión):
// guarda el registro en memoria y responde cuando el panel lo pide.
(() => {
  if (window.__waasBridge) return;
  window.__waasBridge = true;
  const MAX_ENTRIES = 2000;
  const log = [];
  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const d = ev.data;
    if (!d || typeof d !== "object") return;
    if (d.__waas === "log" && d.entry) {
      log.push(d.entry);
      if (log.length > MAX_ENTRIES) log.shift();
    } else if (d.__waas === "getLog") {
      window.postMessage({ __waas: "logResponse", reqId: d.reqId, log }, location.origin);
    } else if (d.__waas === "clearLog") {
      log.length = 0;
    }
  });
})();
