package app.stickerssonido.personal

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Abre WhatsApp Web dentro de un WebView (modo escritorio) e inyecta los scripts de la
 * extensión "Stickers con sonido" (PolyForm Noncommercial 1.0.0, ver LICENSE.md).
 * El botón 🔊 abre/cierra el panel de la extensión; mantenerlo pulsado recarga la página.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val WA_URL = "https://web.whatsapp.com/"

        // true  = como "Sitio de escritorio" en el navegador (lo que ya te funcionó): página ancha y con zoom.
        // false = ancho del celular (WhatsApp Web usa su diseño estrecho; el panel se ve más grande).
        private const val MODO_ESCRITORIO_AMPLIO = true

        // Orden importa: el puente primero, main.js al final.
        private val SCRIPTS = listOf("app_bridge.js", "logger.js", "convert.js", "wa.js", "ui.js", "main.js")
    }

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    // Todos los scripts en un solo texto, con una guarda para no inyectarlos dos veces en la misma página.
    private val bundle: String by lazy {
        val sb = StringBuilder("if(!window.__waasInjected){window.__waasInjected=true;\n")
        for (name in SCRIPTS) {
            sb.append(assets.open("scripts/$name").bufferedReader().use { it.readText() })
            sb.append("\n;\n")
        }
        sb.append("}")
        sb.toString()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        if (debuggable) WebView.setWebContentsDebuggingEnabled(true)

        webView = WebView(this)
        val root = FrameLayout(this)
        root.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        val buttonParams = FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END or Gravity.CENTER_VERTICAL)
        buttonParams.marginEnd = dp(8)
        root.addView(buildButton(), buttonParams)
        setContentView(root)

        configureWebView()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl(WA_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = MODO_ESCRITORIO_AMPLIO
        s.loadWithOverviewMode = MODO_ESCRITORIO_AMPLIO
        s.userAgentString = desktopUserAgent(s.userAgentString)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                val host = uri.host ?: ""
                if (host.endsWith("whatsapp.com") || host.endsWith("whatsapp.net")) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                    // sin app que abra el enlace: se ignora
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (view != null && url != null && url.startsWith(WA_URL)) {
                    view.evaluateJavascript(bundle, null)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent()
                        ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                    fileChooser.launch(intent)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = null
                    false
                }
            }

            // No hace falta micrófono ni cámara: se rechaza cualquier petición.
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.deny()
            }
        }
    }

    // User-Agent de Chrome de escritorio con la misma versión que tiene el WebView del teléfono.
    private fun desktopUserAgent(current: String): String {
        val chrome = Regex("Chrome/([\\d.]+)").find(current)?.groupValues?.get(1) ?: "124.0.0.0"
        return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/$chrome Safari/537.36"
    }

    private fun buildButton(): TextView {
        val b = TextView(this)
        b.text = "🔊"
        b.textSize = 22f
        b.gravity = Gravity.CENTER
        b.setTextColor(Color.WHITE)
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(Color.parseColor("#7C3AED"))
        b.background = circle
        b.alpha = 0.9f
        b.elevation = dp(6).toFloat()
        b.setOnClickListener { togglePanel() }
        b.setOnLongClickListener {
            toast("Recargando WhatsApp Web…")
            webView.reload()
            true
        }
        return b
    }

    private fun togglePanel() {
        val js = "(function(){if(window.WAAS&&window.WAAS.togglePanel){window.WAAS.togglePanel();return true}return false})()"
        webView.evaluateJavascript(js) { result ->
            if (result != "true") toast("El panel aún no está listo. Espera a que cargue WhatsApp Web.")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        webView.destroy()
        super.onDestroy()
    }
}
